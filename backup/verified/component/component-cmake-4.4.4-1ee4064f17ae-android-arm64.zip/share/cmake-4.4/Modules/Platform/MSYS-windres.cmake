include(Platform/CYGWIN-windres)
