set(WASI 1)
